import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

//-------------------------------------------------------------------------
/**
 *  Test class for Doubly Linked List
 *
 *  @author	Elliot Lyons  
 *  @version 13/10/16 18:15
 */
@RunWith(JUnit4.class)
public class DoublyLinkedListTest
{
    //~ Constructor ........................................................
    @Test
    public void testConstructor()
    {
      new DoublyLinkedList<Integer>();
    }

    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check if the insertBefore works
     */
    @Test
    public void testInsertBefore()
    {
        // test non-empty list
        DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
        testDLL.insertBefore(0,1);
        testDLL.insertBefore(1,2);
        testDLL.insertBefore(2,3);

        testDLL.insertBefore(0,4);
        assertEquals( "Checking insertBefore to a list containing 3 elements at position 0", "4,1,2,3", testDLL.toString() );
        testDLL.insertBefore(1,5);
        assertEquals( "Checking insertBefore to a list containing 4 elements at position 1", "4,5,1,2,3", testDLL.toString() );
        testDLL.insertBefore(2,6);       
        assertEquals( "Checking insertBefore to a list containing 5 elements at position 2", "4,5,6,1,2,3", testDLL.toString() );
        testDLL.insertBefore(-1,7);        
        assertEquals( "Checking insertBefore to a list containing 6 elements at position -1 - expected the element at the head of the list", "7,4,5,6,1,2,3", testDLL.toString() );
        testDLL.insertBefore(7,8);        
        assertEquals( "Checking insertBefore to a list containing 7 elemenets at position 8 - expected the element at the tail of the list", "7,4,5,6,1,2,3,8", testDLL.toString() );
        testDLL.insertBefore(700,9);        
        assertEquals( "Checking insertBefore to a list containing 8 elements at position 700 - expected the element at the tail of the list", "7,4,5,6,1,2,3,8,9", testDLL.toString() );

        // test empty list
        testDLL = new DoublyLinkedList<Integer>();
        testDLL.insertBefore(0,1);        
        assertEquals( "Checking insertBefore to an empty list at position 0 - expected the element at the head of the list", "1", testDLL.toString() );
        testDLL = new DoublyLinkedList<Integer>();
        testDLL.insertBefore(10,1);        
        assertEquals( "Checking insertBefore to an empty list at position 10 - expected the element at the head of the list", "1", testDLL.toString() );
        testDLL = new DoublyLinkedList<Integer>();
        testDLL.insertBefore(-10,1);        
        assertEquals( "Checking insertBefore to an empty list at position -10 - expected the element at the head of the list", "1", testDLL.toString() );
     }
    
    
    // Checking if isEmpty() works
    
    
    @Test
    public void testIsEmpty()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	testDLL.insertBefore(0, 1);									// creating a non-empty test list
    	testDLL.insertBefore(1, 2);
    	
    	assertEquals("Checking isEmpty() on a non-empty list", false, testDLL.isEmpty());
    	
    	testDLL = new DoublyLinkedList<Integer>();					// creating an empty test list
    	
    	assertEquals("Checking isEmpty() on an empty list", true, testDLL.isEmpty());
    }

    
    // Checking if get() works
     
    
    @Test
    public void testGet()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	testDLL.insertBefore(0, 1);
    	testDLL.insertBefore(1, 2);									// creating a non-empty test list
    	testDLL.insertBefore(2, 3);
    	
    	assertEquals("Checking get() to a list containing 3 elements at position 0", "1", testDLL.get(0).toString());
    	assertEquals("Checking get() to a list containing 3 elements at position 1", "2", testDLL.get(1).toString());
    	assertEquals("Checking get() to a list containing 3 elements at position 2", "3", testDLL.get(2).toString());
    	
    	testDLL = new DoublyLinkedList<Integer>();					// creating an empty test list
    	
    	assertEquals("Checking get() to a list containing 0 elements at position 0", null, testDLL.get(0));
    	assertEquals("Checking get() to a list containing 0 elements at position 1", null, testDLL.get(1));
    }
    
    
    // Checking if deleteAt() works
    
    
    @Test
    public void testDeleteAt()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	testDLL.insertBefore(0, 1);
    	testDLL.insertBefore(1, 2);									// creating a non-empty test list
    	testDLL.insertBefore(2, 3);
    	testDLL.insertBefore(3, 4);
   
    	assertEquals("Checking deleteAt() to a list containing 4 elements at position 1", true, testDLL.deleteAt(1));
    	assertEquals("Checking list has in fact been modified", "1,3,4", testDLL.toString());
    	
    	assertEquals("Checking deleteAt() to a list containing 3 elements at position 0", true, testDLL.deleteAt(0));
    	assertEquals("Checking list has in fact been modified", "3,4", testDLL.toString());
    	
    	assertEquals("Checking deleteAt() to a list containing 2 elements at position 1", true, testDLL.deleteAt(1));
    	assertEquals("Checking list has in fact been modified", "3", testDLL.toString());
    	
    	assertEquals("Checking an unsuccessful deleteAt() to a list containing 1 element at position 5", false, testDLL.deleteAt(5));
    	assertEquals("Checking the list hasn't been modified", "3", testDLL.toString());
    	
    	testDLL = new DoublyLinkedList<Integer>();					// creating an empty test list
    	
    	assertEquals("Checking an unsuccessful deleteAt() to an empty list", false, testDLL.deleteAt(0));
    }
    
    
    // Checking if reverse() works
    
    
    @Test
    public void testReverse()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	testDLL.insertBefore(0, 100);
    	testDLL.insertBefore(1, 50);						
    	testDLL.insertBefore(2, 77);								// creating a non-empty test list
    	testDLL.insertBefore(3, 90);
    	
    	testDLL.reverse();
    	assertEquals("Checking the reverse of a list containing 4 elements", "90,77,50,100", testDLL.toString());
    	
    	testDLL = new DoublyLinkedList<Integer>();					// creating an empty test list
    	testDLL.reverse();
    	assertEquals("Checking the reverse of an empty list", "", testDLL.toString());	
    }
    
    
    // Checking if makeUnique() works
    
    
    @Test
    public void testMakeUnique()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	testDLL.insertBefore(0, 100);
    	testDLL.insertBefore(1, 50);						
    	testDLL.insertBefore(2, 77);								
    	testDLL.insertBefore(3, 47);								// creating a non-empty test list
    	testDLL.insertBefore(4, 88);
    	testDLL.insertBefore(5, 100);
    	testDLL.insertBefore(6, 50);
    	
    	testDLL.makeUnique();
    	assertEquals("Checking makeUnique() to a list containing 7 elements and 2 duplicated elements", "100,50,77,47,88", testDLL.toString());
    	
    	testDLL = new DoublyLinkedList<Integer>();					// creating an empty test list
    	testDLL.makeUnique();
    	assertEquals("Checking makeUnique() to an empty list", "", testDLL.toString());
    }
    
    
    // Checking if push() works
    
    
    @Test
    public void testPush()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	
    	testDLL.push(1);
    	assertEquals("Checking push to an empty list", "1", testDLL.toString());
    	
    	testDLL.push(2);
    	assertEquals("Checking push to a list of 1 element", "2,1", testDLL.toString());
    	
    	testDLL.push(3);
    	assertEquals("Checking push to a list of 2 elements", "3,2,1", testDLL.toString());
    }
    
    
    // Checking if pop() works
    
    
    @Test
    public void testPop()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();

    	testDLL.push(1);
    	testDLL.push(2);							// creating a non-empty list
    	testDLL.push(3);
    	
    	assertEquals("Checking pop to a list of 3 elements", "3", testDLL.pop().toString());
    	assertEquals("Checking pop to a list of 2 elements", "2", testDLL.pop().toString());
    	assertEquals("Checking pop to a list of 1 element", "1", testDLL.pop().toString());
    	assertEquals("Checking pop to an empty list", null, testDLL.pop());
    }
    
    
    // Checking if enqueue() works
    
    
    @Test
    public void testEnqueue()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
    	
    	testDLL.enqueue(1);
    	assertEquals("Checking enqueue to an empty list", "1", testDLL.toString());
    	
    	testDLL.enqueue(2);
    	assertEquals("Checking enqueue to an empty list", "2,1", testDLL.toString());
    	
    	testDLL.enqueue(3);
    	assertEquals("Checking enqueue to a list of 2 elements", "3,2,1", testDLL.toString());
    	
    	assertEquals("Checking head", "3", testDLL.get(0).toString());
    	assertEquals("Checking tail", "1", testDLL.get(2).toString());
    }
    
    
    // Checking if dequeue() works
    
    
    @Test
    public void testDequeue()
    {
    	DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();

    	testDLL.enqueue(1);
    	testDLL.dequeue();
    	assertEquals("Checking dequeue to a list of 0 elements", "", testDLL.toString());
    	
    	testDLL.enqueue(1);
    	testDLL.enqueue(2);							// creating a non-empty list
    	testDLL.enqueue(3);
    	
    	assertEquals("Checking dequeue to a list of 3 elements", "1", testDLL.dequeue().toString());
    	assertEquals("Checking the list after dequeue", "3,2", testDLL.toString());
    	assertEquals("Checking dequeue to a list of 2 elements", "2", testDLL.dequeue().toString());
    	assertEquals("Checking the list after dequeue", "3", testDLL.toString());
    	assertEquals("Checking dequeue to a list of 1 element", "3", testDLL.dequeue().toString());
    	assertEquals("Checking the list after dequeue", "", testDLL.toString());
    	assertEquals("Checking dequeue to an empty list", null, testDLL.dequeue());
    	assertEquals("Checking the list after dequeue", "", testDLL.toString());
    }
    
    
    // Resolving errors raised by Web-Cat
    
    
    @Test
    public void testErrors()
    {
    	DoublyLinkedList<String> testDLL = new DoublyLinkedList<String>();
    	testDLL.insertBefore(0, "test");
    	testDLL.insertBefore(0, "test");
    	
    	testDLL.makeUnique();
    	assertEquals("Checking made unique", "test", testDLL.toString());
    	
    	assertEquals("Checking a delete at pos 1", false, testDLL.deleteAt(1));
    	assertEquals("Checking a delete at pos 0", true, testDLL.deleteAt(0));
    	assertEquals("Checking if list empty", true, testDLL.isEmpty());
    	
    	DoublyLinkedList<Integer> intTestDLL = new DoublyLinkedList<Integer>();
    	intTestDLL.insertBefore(0, 1);
    	intTestDLL.insertBefore(0, 1);
    	intTestDLL.insertBefore(0, 1);
    	intTestDLL.insertBefore(0, 1);
    	intTestDLL.insertBefore(0, 2);
    	intTestDLL.insertBefore(0, 2);
    	intTestDLL.insertBefore(0, 2);
    	
    	intTestDLL.makeUnique();
    	assertEquals("Checking if list is now unique", "2,1", intTestDLL.toString());
    	
    	intTestDLL = new DoublyLinkedList<Integer>();
    	intTestDLL.insertBefore(0, 1);
    	assertEquals("Checking deleteAt() on a list of one element", true, intTestDLL.deleteAt(0));
    }
}