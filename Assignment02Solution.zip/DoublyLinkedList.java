import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

// -------------------------------------------------------------------------
/**
 *  This class contains the methods of Doubly Linked List.
 *
 *  @author  Elliot Lyons
 *  @version 09/10/18 11:13:22
 */


/**
 * Class DoublyLinkedList: implements a *generic* Doubly Linked List.
 * @param <T> This is a type parameter. T is used as a class name in the
 * definition of this class.
 *
 * When creating a new DoublyLinkedList, T should be instantiated with an
 * actual class name that extends the class Comparable.
 * Such classes include String and Integer.
 *
 * For example to create a new DoublyLinkedList class containing String data: 
 *    DoublyLinkedList<String> myStringList = new DoublyLinkedList<String>();
 *
 * The class offers a toString() method which returns a comma-separated sting of
 * all elements in the data structure.
 * 
 * This is a bare minimum class you would need to completely implement.
 * You can add additional methods to support your code. Each method will need
 * to be tested by your jUnit tests -- for simplicity in jUnit testing
 * introduce only public methods.
 */
class DoublyLinkedList<T extends Comparable<T>>
{

    /**
     * private class DLLNode: implements a *generic* Doubly Linked List node.
     */
    private class DLLNode
    {
        public final T data; // this field should never be updated. It gets its
                             // value once from the constructor DLLNode.
        public DLLNode next;
        public DLLNode prev;
    
        /**
         * Constructor
         * @param theData : data of type T, to be stored in the node
         * @param prevNode : the previous Node in the Doubly Linked List
         * @param nextNode : the next Node in the Doubly Linked List
         * @return DLLNode
         */
        public DLLNode(T theData, DLLNode prevNode, DLLNode nextNode) 
        {
          data = theData;
          prev = prevNode;
          next = nextNode;
        }
    }

    // Fields head and tail point to the first and last nodes of the list.
    private DLLNode head, tail;

    /**
     * Constructor of an empty DLL
     * @return DoublyLinkedList
     */
    public DoublyLinkedList() 
    {
      head = null;
      tail = null;
    }

    /**
     * Tests if the doubly linked list is empty
     * @return true if list is empty, and false otherwise
     *
     * Worst-case asymptotic running time cost: Theta (1)
     *
     * Justification:
     *  This is simply because there is only a return statement in this method. It is of constant time so the worst case running time for the function
     *  is Theta (1)
     */
    public boolean isEmpty()
    {    	
    	return (head == null || tail == null);				// should the tail or the head be empty, the list will also be 
    }

    /**
     * Inserts an element in the doubly linked list
     * @param pos : The integer location at which the new data should be
     *      inserted in the list. We assume that the first position in the list
     *      is 0 (zero). If pos is less than 0 then add to the head of the list.
     *      If pos is greater or equal to the size of the list then add the
     *      element at the end of the list.
     * @param data : The new data of class T that needs to be added to the list
     * @return none
     *
     * Worst-case asymptotic running time cost: Theta (N)
     *
     * Justification:
     *  We have a number of calls to one external method: isEmpty(). We know that its asymptotic run time is Theta (1) as above.
     *  We also know creating a new node also has an asymptotic run time of Theta (1).
     *  The other operations are declarations and if statements which also have an asymptotic run time of Theta (1).
     *  
     *  However, we also have a while loop. The worst case scenario is that it runs to the end of the doubly linked list.
     *  As above, all operations in the loop have an asymptotic run time of Theta (1). Letting N equal the length of the doubly linked list,
     *  the while loop will execute the linear operations N times in the worst-case.
     *  
     *  Because of this cost of the entire method will be N * Theta (1) = Theta (N).
     */
    public void insertBefore( int pos, T data ) 
    {
    	DLLNode newNode;
   
    	int count = 0;
    	DLLNode temp = head;
      
    	while (count <= pos || pos <= 0)
    	{
    		if (count == pos || pos <= 0)
    		{
    			if (pos <= 0)												// if we are inserting at the head of the DLL
    			{
    				newNode = new DLLNode(data, null, head);
    				
    				if (isEmpty())
    				{
    					tail = newNode;										// if the list is empty, the head will also be the tail
    				}
    				
    				else
    				{
    					temp.prev = newNode;								// if not the old head needs to now point to the new head (newNode)
    				}
    				
    				head = newNode;											// updating the head to be the new head
    				return;
    			}
    			
    			else if (temp == null)										// if we are inserting at the end of the DLL
    			{
    				if (isEmpty())
    				{
    					newNode = new DLLNode(data, head, tail);			// if the list is empty, we need to update head to equal the new node
    					head = newNode;
    				}
    				
    				else													
    				{
    					newNode = new DLLNode(data, tail, null);			// if the list isn't empty
    					tail.next = newNode;								// we need to point the old tail to the new tail (newNode)
    				}
    				
    				tail = newNode;											// updating tail to point to the new tail (newNode)
    				return;
    			}
    			
    			else														// if we are inserting somewhere in the middle of the DLL
    			{
    				newNode = new DLLNode(data, temp.prev, temp);
    				newNode.prev.next = newNode;
    				newNode.next.prev = newNode;
    				return;
    			}
    		}
    		
    		count++;
    		
    		if (temp != null)
    		{
    			temp = temp.next;
    		}
    	}
    }

    /**
     * Returns the data stored at a particular position
     * @param pos : the position
     * @return the data at pos, if pos is within the bounds of the list, and null otherwise.
     *
     * Worst-case asymptotic running time cost: Theta (N)
     *
     * Justification:
     *  As with the insertBefore() method, we only have one external method call which is to isEmpty().
     *  There is also a while loop that in the worst case scenario will run to the end of the doubly linked list.
     * 	Within the loop, there is constant time operations. Again allowing the doubly linked list to be of length N,
     * 	we can say the worst case asymptotic cost of the entire method is N * Theta(1) = Theta(N).
     *
     */
    public T get(int pos) 
    {
    	if (!isEmpty())
    	{
    		DLLNode temp = head;
    		int count = 0;
      
    		while (temp != null)						// iterating through the list until we are at the desired position
    		{  
    			if (count == pos)
    			{
    				return temp.data;
    			}
    	  
    			count++;
    			temp = temp.next;
    		}
    	}
    	
      return null;										// if pos is out of the bounds of the list or the list is empty we return null
    }

    /**
     * Deletes the element of the list at position pos.
     * First element in the list has position 0. If pos points outside the
     * elements of the list then no modification happens to the list.
     * @param pos : the position to delete in the list.
     * @return true : on successful deletion, false : list has not been modified. 
     *
     * Worst-case asymptotic running time cost: Theta (N)
     *
     * Justification:
     *  As with the two methods above we have one while loop in the method, with all other operations being constant time operations.
     *  The worst case scenario will also see this while loop executing until the end of the doubly linked list. Allowing the doubly linked list to 
     *  have a length of N, we can again say the asymptotic run time is N * Theta (1) = Theta (N).
     */
    public boolean deleteAt(int pos) 
    {
    	if (!isEmpty())
    	{
    		DLLNode temp = head;
    		int count = 0;
      
    		while (count <= pos && temp != null)				// iterating through the list until we reach pos / the end of the list
    		{
    			if (count == pos)
    			{
    				if (count == 0)								// if we are deleting at the head of the list
    				{
    					head = head.next;						// we update the head to be the next element in the list
    					
    					if (head != null)						// if the list is still not empty after deletion, we have to update the new 
    					{										// head's pointer to the previous node
    						head.prev = null;					// we update it to null
    					}
    				}
    				
    				else
    				{
    					if (temp.next == null)					// if we are deleting at the tail of the list
    					{
    						tail = temp.prev;					// we need to update the tail to point to the element before
    					}
    					
    					else									// if we are deleting in the middle of the list
    					{
   							temp.next.prev = temp.prev;			// we need to update the next node's previous pointer to the element previous to the
   						}										// element we are deleting
   						
   						temp.prev.next = temp.next;				// regardless of deleting at the end / middle, we need to point the previous node's next 
    				}											// pointer to the next pointer of the element we are deleting
    				
    				return true;								// successful deletion has been achieved
    			}
    				
    			temp = temp.next;
    			count++;
    		}
    	}
      
      return false;												// successful deletion has not been achieved
    }

    /**
     * Reverses the list.
     * If the list contains "A", "B", "C", "D" before the method is called
     * Then it should contain "D", "C", "B", "A" after it returns.
     *
     * Worst-case asymptotic running time cost: Theta (N)
     *
     * Justification:
     *  There is one while loop in this method. All other operations and method calls are constant time operations.
     *  As the while loop can run through the entire doubly linked list of length N, we say the worst-case asymptotic run time is N * Theta (1) = Theta (N)
     */
    public void reverse()
    {
      if (!isEmpty())
      {
    	DLLNode temp = head;
    	head = tail;											// switching the tail and head pointers of the list
    	tail = temp;
    	
    	while (temp != null)									// iterating backwards through the list
    	{
    		DLLNode tempOne = temp.prev;
    		temp.prev = temp.next;								// switching the previous and next pointers for each element in the list
    		temp.next = tempOne;
    		temp = temp.prev;
    	}
      }
    }
    
    /**
     * Removes all duplicate elements from the list.
     * The method should remove the _least_number_ of elements to make all elements uniqueue.
     * If the list contains "A", "B", "C", "B", "D", "A" before the method is called
     * Then it should contain "A", "B", "C", "D" after it returns.
     * The relative order of elements in the resulting list should be the same as the starting list.
     *
     * Worst-case asymptotic running time cost: Theta (N^2)
     *
     * Justification:
     *  There are two for loops in this method. The other operations in the method cost a constant time. In the worst case scenario both for loops run 
     *  through the entire doubly linked list. If the list has a length of N that means the cost of this method is N * (N-1) * Theta (1) = Theta (N^2 - N).
     *  As we only focus on the highest order term, the worst case running time is Theta (N^2).
     */
     public void makeUnique()
    {
    	 if (!isEmpty())
    	 {
    		 int count = 0;
    	 
    		 for (DLLNode tempOne = head; tempOne != null; tempOne = tempOne.next)					// iterating through the entire list
    		 {
    			 int otherCount = count + 1;
    		 
    			 for (DLLNode tempTwo = tempOne.next; tempTwo != null; tempTwo = tempTwo.next)		// we then iterate from the next element through the
    			 {																					// rest of the list
    				 if (tempTwo.data == tempOne.data && tempTwo != null)
    				 {
    					 deleteAt(otherCount);														// if we find an element equal to one previous in the
    				 }																				// list, we delete it
    			 
    				 else
    				 {
    					 otherCount++;
    				 }
    			 }
    		 
    			 count++;
    		 }
    	 } 
      }


    /*----------------------- STACK API 
     * If only the push and pop methods are called the data structure should behave like a stack.
     */

    /**
     * This method adds an element to the data structure.
     * How exactly this will be represented in the Doubly Linked List is up to the programmer.
     * @param item : the item to push on the stack
     *
     * Worst-case asymptotic running time cost: Theta (1)
     *
     * Justification:
     *  We can simply call the insertBefore method passing in the head as the position and the data. As insertBefore runs at a constant time, push does too
     */
    public void push(T item) 
    {
    	insertBefore(0, item);
    }

    /**
     * This method returns and removes the element that was most recently added by the push method.
     * @return the last item inserted with a push; or null when the list is empty.
     *
     * Worst-case asymptotic running time cost: Theta (1)
     *
     * Justification:
     *  We only are executing constant time operations in this method once. This gives it the asymptotic running time of Theta (1). 
     */
    public T pop() 
    {
      DLLNode temp = head;
      
      if (temp != null)											// if head isn't null,
      {
    	  head = temp.next;										// we need to update the next element to point to the head
    	  
    	  if (head != null)										// if the new head doesn't = null,
    	  {
    		  head.prev = null;									// we need to update the previous pointer of the new head to = null
    	  }
    	  return temp.data;
      }
      
      return null;
    }

    /*----------------------- QUEUE API
     * If only the enqueue and dequeue methods are called the data structure should behave like a FIFO queue.
     */
 
    /**
     * This method adds an element to the data structure.
     * How exactly this will be represented in the Doubly Linked List is up to the programmer.
     * @param item : the item to be enqueued to the stack
     *
     * Worst-case asymptotic running time cost: Theta (1)
     *
     * Justification:
     *  As with the push() method, we can simply call the insertBefore method. As insertBefore() has a constant running time, enqueue does as well
     */
    public void enqueue(T item) 
    {
    	insertBefore(0, item); 
    }

     /**
     * This method returns and removes the element that was least recently added by the enqueue method.
     * @return the earliest item inserted with an enqueue; or null when the list is empty.
     *
     * Worst-case asymptotic running time cost: Theta (1)
     *
     * Justification:
     *  As with the pop() method we are only doing constant time operations in this method. We only do them once, meaning a worst case run time of 
     *  Theta (1).
     */
    public T dequeue() 
    {
    	if (!isEmpty())
    	{
    		DLLNode temp = tail;
      
    		if (tail != null && tail.prev != null)				// if tail or the element before tail isn't null,
    		{
    			temp.prev.next = null;							// we update the next pointer of the element before tail to be null
    		}
    		
    		if (tail.prev == null)								// if the element before tail points to null, the list will become empty once we dequeue
    		{													// the current element
    			head = null;									// thus, we must update the head pointer to point to null
    		}
      
    		tail = temp.prev;
    		return temp.data;
    	}
    	
      return null;
    }
 

    /**
     * @return a string with the elements of the list as a comma-separated
     * list, from beginning to end
     *
     * Worst-case asymptotic running time cost:   Theta(n)
     *
     * Justification:
     *  We know from the Java documentation that StringBuilder's append() method runs in Theta(1) asymptotic time.
     *  We assume all other method calls here (e.g., the iterator methods above, and the toString method) will execute in Theta(1) time.
     *  Thus, every one iteration of the for-loop will have cost Theta(1).
     *  Suppose the doubly-linked list has 'n' elements.
     *  The for-loop will always iterate over all n elements of the list, and therefore the total cost of this method will be n*Theta(1) = Theta(n).
     */
    public String toString() 
    {
      StringBuilder s = new StringBuilder();
      boolean isFirst = true; 

      // iterate over the list, starting from the head
      for (DLLNode iter = head; iter != null; iter = iter.next)
      {
        if (!isFirst)
        {
          s.append(",");
        } else {
          isFirst = false;
        }
        s.append(iter.data.toString());
      }

      return s.toString();
    }
}