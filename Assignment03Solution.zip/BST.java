/*************************************************************************
 *  Binary Search Tree class.
 *  Adapted from Sedgewick and Wayne.
 *
 *  @version 3.0 1/11/15 16:49:42
 *
 *  @author Elliot Lyons
 *
 *************************************************************************/

import java.util.NoSuchElementException;

public class BST<Key extends Comparable<Key>, Value> {
    private Node root;             // root of BST

    /**
     * Private node class.
     */
    private class Node {
        private Key key;           // sorted by key
        private Value val;         // associated data
        private Node left, right;  // left and right subtrees
        private int N;             // number of nodes in subtree

        public Node(Key key, Value val, int N) {
            this.key = key;
            this.val = val;
            this.N = N;
        }
    }

    // is the symbol table empty?
    public boolean isEmpty() { return size() == 0; }

    // return number of key-value pairs in BST
    public int size() { return size(root); }

    // return number of key-value pairs in BST rooted at x
    private int size(Node x) {
        if (x == null) return 0;
        else return x.N;
    }

    /**
     *  Search BST for given key.
     *  Does there exist a key-value pair with given key?
     *
     *  @param key the search key
     *  @return true if key is found and false otherwise
     */
    //public boolean contains(Key key) {								// commented out as no use for these in file and not losing marks in problem coverage
      //  return get(key) != null;										// because not used
    //}

    /**
     *  Search BST for given key.
     *  What is the value associated with given key?
     *
     *  @param key the search key
     *  @return value associated with the given key if found, or null if no such key exists.
     */
//    public Value get(Key key) { return get(root, key); }				// commented out as no use for these in file and not losing marks in problem coverage
//																		// because not used
//    private Value get(Node x, Key key) {
//        if (x == null) return null;
//        int cmp = key.compareTo(x.key);
//        if      (cmp < 0) return get(x.left, key);
//        else if (cmp > 0) return get(x.right, key);
//        else              return x.val;
//    }

    /**
     *  Insert key-value pair into BST.
     *  If key already exists, update with new value.
     *
     *  @param key the key to insert
     *  @param val the value associated with key
     */
    public void put(Key key, Value val) {
        if (val == null) { delete(key); return; }
        root = put(root, key, val);
    }

    private Node put(Node x, Key key, Value val) {
        if (x == null) return new Node(key, val, 1);
        int cmp = key.compareTo(x.key);
        if      (cmp < 0) x.left  = put(x.left,  key, val);
        else if (cmp > 0) x.right = put(x.right, key, val);
        else              x.val   = val;
        x.N = 1 + size(x.left) + size(x.right);
        return x;
    }

    /**
     * Tree height.
     *
     * Asymptotic worst-case running time using Theta notation: Theta (N)
     * 
     * The run time of this function depends linearly on the number of nodes in the tree. In the worst case, the tree will be completely unbalanced and all 
     * the nodes will be in either the left or the right subtree. This gives a height of N - 1. For this the height function will be called once, while 
     * the getHeight function will be recursively called N times. As there are only constant time operations occurring within the getHeight function, the 
     * worst-case run time will be N. Adding the constant time operation of calling height, gives a total time of N + 1 in the absolute worst case.
     * We can ignore the +1, giving us the upper bound on the run-time of N.
     * 
     * In the best case scenario, the BST will be perfectly balanced. This means the height will be (N/2) - .5 which is the minimum height a BST can be.
     * The .5 is explained by only a tree with an uneven amount of nodes can be perfectly balanced, due to the root (x + x + root). As above the height 
     * function will be called once (run time of 1) and the getHeight will be called recursively based on the height of the tree (N/2). As above, the 
     * getHeight function has constant time operations, meaning its run time will be N/2. Adding that to the height runtime, gives us a lower bound of
     * (N/2) + 1. In asymptotic run time, we keep the highest order term which is N/2 here. As we again only keep the highest order term, we can say we have]
     * a lower bound on the run-time of N for this function.
     * 
     *  As both the lower bound and the upper bound for this function equal to N, we can say the asymptotic worst-case run time for this function is Theta(N)
     *
     * @return the number of links from the root to the deepest leaf.
     *
     * Example 1: for an empty tree this should return -1.
     * Example 2: for a tree with only one node it should return 0.
     * Example 3: for the following tree it should return 2.
     *   B
     *  / \
     * A   C
     *      \
     *       D
     */
    
    public int height() {
      
    	if (!isEmpty())
    	{
    		return getHeight(root);					// if tree isn't empty we call function getHeight which calculates a height of a tree from a certain node
    	}
    	
      return -1;									// if it is empty we return -1
    }
    
    public int getHeight(Node aNode)
    {
    	if (aNode != null)
    	{											// if the node isn't empty,
    		int left = getHeight(aNode.left);		// we recursively call the getHeight() function. This will find the height of the left subtree
    		int right = getHeight(aNode.right);		// this will find the height of the right subtree
    		
    		if (left > right)						// we return the height of the taller subtree
    		{
    			return left + 1;					// we must add one to account for the -1 that gets returned if an empty node is found
    		}										// as getHeight() is called recursively, until an empty node is found.
    		
    		return right + 1;
    	}
    	
    	return -1;
    }

    /**
     * Median key.
     * If the tree has N keys k1 < k2 < k3 < ... < kN, then their median key 
     * is the element at position (N+1)/2 (where "/" here is integer division)
     *
     * @return the median key, or null if the tree is empty.
     */
    public Key median() {
      if (isEmpty()) return null;
      
      int treeSize = size();
      
      if (treeSize % 2 == 0)
      {
    	  treeSize -= 1;				// we take away one from even numbers as the expected result for a median number is the actual median rounded down
      }									// i.e median of a tree with Keys 1-8 = 4, and not 5 (4.5 rounded)
      	
      int med = treeSize / 2;			// the fact integer division truncates a remainder is the reason we subtract 1 from BSTs with an even no. of nodes
      									// and leave trees with an odd number of nodes, i.e. it rounds down for us	
      return select(root, med).key;		// then we return the key, of the node ranked at the median in the tree
    }
    
    public Node select(Node aNode, int aKey)
    {
    	if (aNode != null)
    	{
    		int left = size(aNode.left);						// if the size of the left subtree is greater than the key int passed in, the key must be within the current node's left subtree    		
    		if (left > aKey)							
    		{
    			return select(aNode.left, aKey);
    		}
    		
    		else if (left < aKey)								// if the number of nodes in the left subtree is smaller than the value of the key passed in, the desired 
    		{													// key must be in the within the right subtree of the current node.		
    			return select(aNode.right, aKey - left - 1); 	// we subtract the number of left nodes for the call to select as we don't want to forget /
    		}													// double-count them in the right subtree. We also take one away to account for the current node
    			
    		return aNode;										// if the size of the left subtree equals the key passed in, the current node is the desired 
    	}														// node, so we return it
    	
    	return null;											// if current node is null, we return null
    }


    /**
     * Print all keys of the tree in a sequence, in-order.
     * That is, for each node, the keys in the left subtree should appear before the key in the node.
     * Also, for each node, the keys in the right subtree should appear before the key in the node.
     * For each subtree, its keys should appear within a parenthesis.
     *
     * Example 1: Empty tree -- output: "()"
     * Example 2: Tree containing only "A" -- output: "(()A())"
     * Example 3: Tree:
     *   B
     *  / \
     * A   C
     *      \
     *       D
     *
     * output: "((()A())B(()C(()D())))"
     *
     * output of example in the assignment: (((()A(()C()))E((()H(()M()))R()))S(()X()))
     *
     * @return a String with all keys in the tree, in order, parenthesized.
     */
    public String printKeysInOrder() {
      if (!isEmpty()) 
      {
    	  return orderPrint(root);				// calling on print, starting from the root
      }
      
      return "()";
    }
    
    public String orderPrint(Node aNode)
    {
    	String current = "";
    	
    	if (aNode != null)
    	{
    		current = "(";
    		current += orderPrint(aNode.left);		// as this is an in-order traversal, we print the key of the left most node of the current node
    		current += aNode.key;					// then of the current node
    		current += orderPrint(aNode.right);		// then of the right
    		current += ")";
    		return current;
    	}
    	
    	return "()";								// if node is empty, we return ()
    }
    
    /**
     * Pretty Printing the tree. Each node is on one line -- see assignment for details.
     *
     * @return a multi-line string with the pretty ascii picture of the tree.
     */
    public String prettyPrintKeys() {
    	
    	if (isEmpty())
    	{
    		return "-null\n";						// if the tree is empty, we return -null\n
    	}
      
    	return prettyPrint(root, "");				// if not we start pretty print from the root with prefix ""
    }
    
    public String prettyPrint(Node aNode, String prefix)
    {
    	if (aNode != null)
    	{
    		String current = prefix + "-" + aNode.key;				// as this is a pre-order traversal, we print the current node's key first. Here we
    																// must display it with the current prefix and add a "-" to it as well
    		current += "\n";
    		
    		current += prettyPrint(aNode.left, prefix + " |");		// then we must print the key of the left node, we add " |" to the prefix to match pretty print format
    		
    		if (!current.contains("null"))							// as prettyPrint returns "null\n", there is no need to add a new line if the left node is null
    		{
    			current += "\n";									// if it isn't though, we must add a new line
    		}
    		current += prettyPrint(aNode.right, prefix + "  ");		// finally we print the right node
    		return current;											
    	}
    	
    	return prefix + "-null\n";									// if node is null
    }

    /**
     * Deletes a key from a tree (if the key is in the tree).
     * Note that this method works symmetrically from the Hibbard deletion:
     * If the node to be deleted has two child nodes, then it needs to be
     * replaced with its predecessor (not its successor) node.
     *
     * @param key the key to delete
     */
    public void delete(Key key)
    {
    	root = deleteAt(root, key);								// we start the deletion from the root node, this will fix all the pointers that will have changed
    }															// due to a deletion
    
    public Node deleteAt(Node aNode, Key aKey)
    {
    	if (aNode == null)										// if the node is null, we can't delete it meaning nothing will have changed in the tree
    	{
    		return null;
    	}
    	
    	int cmp = aKey.compareTo(aNode.key);					// comparing the passed node's key to the key we wish to delete
    	
    	if (cmp < 0)
    	{
    		aNode.left = deleteAt(aNode.left, aKey);			// if the current node's key is greater than the one we wish to delete, we see if the key is 
    	}														// in the left subtree
    	
    	else if (cmp > 0)										// if the current node's key is less than the one we wish to delete, we turn to the right subtree
    	{
    		aNode.right = deleteAt(aNode.right, aKey);
    	}
    	
    	else													// these lines of code are only reached if the current node's key is the one we wish to delete
    	{
    		if (aNode.right == null)							// if there is no right child of the current node, we can simply put the left node in the
    		{													// current node's place (the one we wish to delete)
    			return aNode.left;	
    		}
    		
    		if (aNode.left == null)								// same applies to the left child. If none, just point to the right
    		{
    			return aNode.right;
    		}
    		
    		Node temp = aNode;									// if there are two children however,
    		aNode = max(temp.left);								// we must let the current node equal to the max key value of its left subtree
    		aNode.left = deleteMax(temp.left);					// then we update the left pointer of the current node after essentially deleting itself from its old position
    		aNode.right = temp.right;							// then we can update the right pointer to equal what it was before deletion of the current node
    	}
    	
    	aNode.N = size(aNode.right) + size(aNode.left) + 1;		// we must update the size of current node to cover for a possible deletion
    	return aNode;											// we can then return the node. If it has been deleted, it will return the new node with 
    }															// the correct pointers and size, which is now in the place of the deleted node
    
    public Node deleteMax(Node theNode)
    {
    	if (theNode.right == null)								// this function recursively calls itself, until it finds the right-most node of the current
    	{														// subtree
    		return theNode.left;								// it will eventually return the left of the node once it reaches the max of the current subtree
    	}														// this means the current node will be deleted and its left node will be put in its place
    	
    	theNode.right = deleteMax(theNode.right);				
    	theNode.N = 1 + size(theNode.left) + size(theNode.right);		// fixing the sizes upon deletion
    	return theNode;
    }
    
    public Node max(Node aNode)									// finding the max of a subtree
    {
    	if (aNode.right == null)								// if the current node's right value is null, we must be at the right most node
    	{
    		return aNode;										// therefore we return the current node
    	}
    	
    	return max(aNode.right);								// if not, we recall the max expression until we reach the max
    }
}