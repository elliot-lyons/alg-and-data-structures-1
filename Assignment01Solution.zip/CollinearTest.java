import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.Arrays;

//-------------------------------------------------------------------------
/**
 *  Test class for Collinear.java
 *
 *  @author  
 *  @version 18/09/18 12:21:26
 */
@RunWith(JUnit4.class)
public class CollinearTest
{
    //~ Constructor ........................................................
    @Test
    public void testConstructor()
    {
      new Collinear();
    }
    
	/** public static void main(String[] args)
	{
		String fileOne = "C:/Users/ellio/eclipse-workspace/AlgTut01/input-files/r04000-1.txt";
		String fileTwo = "C:/Users/ellio/eclipse-workspace/AlgTut01/input-files/r04000-2.txt";
		String fileThree = "C:/Users/ellio/eclipse-workspace/AlgTut01/input-files/r04000-3.txt";
		
		In inOne = new In(fileOne);
		int[] a = inOne.readAllInts();
		In inTwo = new In(fileTwo);
		int[] b = inTwo.readAllInts();
		In inThree = new In(fileThree);
		int[] c = inThree.readAllInts();
		
		Stopwatch stopwatch = new Stopwatch();
		StdOut.println(Collinear.countCollinearFast(a, b, c));
		double time = stopwatch.elapsedTime();
		StdOut.println("elapsed time " + time);
	}
	*/

    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check that the two methods work for empty arrays
     */
    @Test
    public void testEmpty()
    {
        int expectedResult = 0;

        assertEquals("countCollinear failed with 3 empty arrays",       expectedResult, Collinear.countCollinear(new int[0], new int[0], new int[0]));
        assertEquals("countCollinearFast failed with 3 empty arrays", expectedResult, Collinear.countCollinearFast(new int[0], new int[0], new int[0]));
    }

    // ----------------------------------------------------------
    /**
     * Check for no false positives in a single-element array
     */
    @Test
    public void testSingleFalse()
    {
        int[] a3 = { 15 };
        int[] a2 = { 5 };
        int[] a1 = { 10 };

        int expectedResult = 0;

        assertEquals("countCollinear({10}, {5}, {15})",       expectedResult, Collinear.countCollinear(a1, a2, a3) );
        assertEquals("countCollinearFast({10}, {5}, {15})", expectedResult, Collinear.countCollinearFast(a1, a2, a3) );
    }

    // ----------------------------------------------------------
    /**
     * Check for no false positives in a single-element array
     */
    @Test
    public void testSingleTrue()
    {
        int[] a3 = { 15, 5 };       int[] a2 = { 5 };       int[] a1 = { 10, 15, 5 };

        int expectedResult = 1;

        assertEquals("countCollinear(" + Arrays.toString(a1) + "," + Arrays.toString(a2) + "," + Arrays.toString(a3) + ")",     expectedResult, Collinear.countCollinear(a1, a2, a3));
        assertEquals("countCollinearFast(" + Arrays.toString(a1) + "," + Arrays.toString(a2) + "," + Arrays.toString(a3) + ")", expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }


    // ----------------------------------------------------------
    /**
     * Check for collinearity in the left diagonal
     */
    @Test
    public void testLeftDiagonal()
    {
    	int[] a1 = {3, 9, 7};
    	int[] a2 = {22, 5};
    	int[] a3 = {1};
    	
    	int expectedResult = 1;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }
    
 // ----------------------------------------------------------
    /**
     * Check for collinearity in the right diagonal
     */
    @Test
    public void testRightDiagonal()
    {
    	int[] a1 = {1, 8};
    	int[] a2 = {5};
    	int[] a3 = {100, 45, 88, 9, 27};
    	
    	int expectedResult = 1;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }
    
 // ----------------------------------------------------------
    /**
     * Check for multiple collinearity in the left diagonal
     */
    @Test
    public void testMultipleLeftDiagonal()
    {
    	int[] a1 = {3, 9, 7, 23, 88, 61};
    	int[] a2 = {22, 2, 20, 60};
    	int[] a3 = {1, 21, 47, 59};
    	
    	int expectedResult = 3;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }
    
 // ----------------------------------------------------------
    /**
     * Check for multiple collinearity in the right diagonal
     */
    @Test
    public void testMultipleRightDiagonal()
    {
    	int[] a1 = {1, 8, 12, 44, 55};
    	int[] a2 = {2, 9, 13};
    	int[] a3 = {100, 45, 88, 14, 3, 10, 27};
    	
    	int expectedResult = 3;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }
    
    /**
     * Check for multiple collinearity in the left and right diagonal and the vertical direction
     */
    
    @Test
    public void testMultiplePositives()
    {
    	int[] a1 = {1, 11, 62, 101};
    	int[] a2 = {2, 62, 10};
    	int[] a3 = {333, 62, 3, 9, 87 };
    	
    	int expectedResult = 3;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    }
    
    /**
     * Check for multiple negatives even when there is a small line between two points ((1,1)->(1,2)
     * and (12,2)->(13,3))
     */
    
    @Test
    public void testMultipleNegatives()
    {
    	int[] a1 = {787, 89, 1, 7};
    	int[] a2 = {12, 1, 999};
    	int[] a3 = {77, 13};
    	
    	int expectedResult = 0;
    	
    	assertEquals(expectedResult, Collinear.countCollinear(a1, a2, a3));
    	assertEquals(expectedResult, Collinear.countCollinearFast(a1, a2, a3));
    
    }
}


