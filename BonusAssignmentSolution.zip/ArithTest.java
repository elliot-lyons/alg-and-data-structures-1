import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

public class ArithTest {

	@Test
	public void test() {
		
		/* 
		 * I edited my constructor for Arith so that a passed in string will become a string array. The array is stored as a public string array called sum
		 * Eg below the testArith.sum refers to the sum I passed into the Arith constructor for testArith
		 */
		
		Arith testArith = new Arith("((((((4*3)+(4*7))+9)*6)+(3-2))/5)");
		assertEquals("Testing if valid infix order", true, testArith.validateInfixOrder(testArith.sum));
		assertEquals("Testing if evaluates correctly", ((((((4*3)+(4*7))+9)*6)+(3-2))/5), testArith.evaluateInfixOrder(testArith.sum));
		
		Arith t = new Arith("5+2+3");
		
		assertEquals("Testing if valid infix order", true, testArith.validateInfixOrder(t.sum));
		assertEquals("Testing if evaluates correctly", 5+2+3, testArith.evaluateInfixOrder(t.sum));
		
		Arith other = new Arith("6/9+(5*6))");
		assertEquals("Testing an invalid infix order", false, other.validateInfixOrder(other.sum));
		
		Arith another = new Arith("(6/(9+(5*6)))");
		assertEquals("Testing a valid infix order", true, another.validateInfixOrder(another.sum));
		
		
		String[] y = new String[17];			// y = correct postfix representation of in infix expression 'testArith'
		int i = 0;
		
		y[i] = "4";
		y[++i] = "3";
		y[++i] = "*";
		y[++i] = "4";
		y[++i] = "7";
		y[++i] = "*";
		y[++i] = "+";
		y[++i] = "9";
		y[++i] = "+";
		y[++i] = "6";
		y[++i] = "*";
		y[++i] = "3";
		y[++i] = "2";
		y[++i] = "-";
		y[++i] = "+";
		y[++i] = "5";
		y[++i] = "/";
		
		assertEquals("Converting infix to postfix",y, testArith.convertInfixToPostfix(testArith.sum));
		assertEquals("Converting postfix to infix", testArith.convertPostfixToInfix(y), testArith.sum);
	}

}
