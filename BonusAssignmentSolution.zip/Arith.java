import java.io.*;
import java.util.*;

// -------------------------------------------------------------------------
/**
 *  Utility class containing validation/evaluation/conversion operations
 *  for infix arithmetic expressions.
 *
 *  @author  Elliot Lyons
 *  @version 1/12/15 13:03:48
 */

public class Arith 
{
	public String[] sum;
	Arith(String input)
	{
		sum = new String[input.length()];					// creating a String array from a passed input String
		
		for (int i = 0; i < input.length(); i++)
		{
			char x = input.charAt(i);
			sum[i] = Character.toString(x);
		}
	}

  //~ Validation methods ..........................................................


  /**
   * Validation method for infix notation.
   *
   * @param infixLiterals : an array containing the string literals hopefully in infix order.
   * The method assumes that each of these literals can be one of:
   * - "+", "-", "*", or "/"
   * - or a valid string representation of an integer "0", "1" , "2", ..., "-1", "-2", ...
   *
   * @return true if the parameter is indeed in infix notation, and false otherwise.
   **/
	
	
	/*
	 * I believe my method to be the most efficient method possible in terms of run time and memory usage. I think this because memory is only occupied by 
	 * 8 variables and the string giving it space complexity Theta (N). We must run through the entire string meaning run time time complexity is Theta (N) 
	 * as well. This is because there is a for loop of the length of the string array. Within the for loop there is only constant time operations. 
	 */
	
	
  public static boolean validateInfixOrder(String infixLiterals[])
  {
	  String current;
	  boolean isOperation = true;			// isOperation tracks whether the last string was an operation. We set is as true for the first element as
	  										// if the first element of the string isn't an operation, the array is not an infix array
	  boolean isNumber = false;				// this keeps track of whether the last element was a number
	  boolean isCloseBrack = false;
	  
	  int leftBrack = 0;					// these keep track of how many of each brackets there are. If they don't match at the end, we return false
	  int rightBrack = 0;
	  
	  for (int i = 0; i < infixLiterals.length; i++)		// this checks all the strings in the array. If the loop finds two consecutive strings that 
	  {														// aren't numbers, we return false
		  current = infixLiterals[i];
		  
		  switch (current)
		  {
		  	case("+"):
		  	case("-"):
		  	case("*"):
		  	case("/"):
		  		
		  		if (isOperation)							// this will be true if the last string was an operation string or if we are on the first string
		  		{											// if either is true, we need to return false
		  			return false;
		  		}
		  		
		  		else
		  		{
		  			isOperation = true;						// if not, we need to change isOperation to true, so we can make sure the next string is a number
		  			isNumber = false;						// we also need to set isNumber to false, as the last element is now not a number
		  			isCloseBrack = false;
		  		}
		  	break;
		  	
		  	case ("("):
		  		leftBrack++;
		  		isNumber = false;
		  		break;
		  		
		  	case(")"):
		  		isNumber = false;
		  		isOperation = false;
		  		rightBrack++;
		  		isCloseBrack = true;
		  		
		  		break;
		  	
		  	default:
		  		if (isNumber)
		  		{
		  			return false;							// if the previous element was a number, we can't have two numbers in a row. We must return
		  		}											// false
		  		isOperation = false;						
		  		isNumber = true;
		  		isCloseBrack = false;
		  }													
	  }
	  
	  if (leftBrack != rightBrack)
	  {
		  return false;
	  }
	  
	  if (isCloseBrack == true)
	  {
		  return true;
	  }
	  
	  return !isOperation;									// we return the inverse of isOperation. The last string can't be an operation string,
  }															// isOperation will be true if it is. It must be a number. isOperation will be false if the last
  															// string is a number. Hence we return the inverse of isOperation.
  
  //~ Evaluation  methods ..........................................................


  /**
   * Evaluation method for infix notation.
   *
   * @param infixLiterals : an array containing the string literals in infix order.
   * The method assumes that each of these literals can be one of:
   * - "+", "-", "*", or "/"
   * - or a valid string representation of an integer.
   *
   * @return the integer result of evaluating the expression
   **/
  
  /*
   * The worst-case run time of this algorithm is Theta (N). This is because the while loop runs through the entire passed String Array. Although there is recursion
   *  in this function, when the function calls itself, the run time does not go to Theta(N^2). This is despite the fact we enter embedded for loops. This is because
   *  the Strings dealt with in these for loops, are recorded and 'skipped' in the outer for loops. Space complexity is also O(N), as even though we store 
   *  multiple String arrays we ignore the number and focus on the bigger order term in our analysis.
   *  
   */
  
  public static int evaluateInfixOrder(String infixLiterals[])		// in this function we recursively call it to evaluate smaller sums
  {																	// eg if the string '(5+(2+4))' passed in, we will call the evaluate function with the (2+4)
	  String operation = "";										// passed in
	  int x = 0;
	  int y = 0;
	  boolean op = false;
	  int i = 0;
	  boolean first = false;
	  boolean done = false;
	  boolean second = false;
	  
	  while (i < infixLiterals.length && !done)						// looping through the sum. We will break from loop if one sum is done or if we are at end of string
	  {
		  boolean open = false;						
		  int gap = 1;												// this gap tracks how many strings we need to skip if we recursively call the function.
		  															// eg in example above, we will skip over the (2+4) in the original function call as 
		  switch (infixLiterals[i])									// we will pass the 2+4 into the function by itself. If we didn't 'skip' over the 2+4, we
		  {															// would do the sum twice
	  		case ("+"):
	  		{
	  			op = true;
	  			operation = "+";
	  			break;
	  		}
	  	
		  	case("-"):
		  	{
		  		op = true;
		  		operation = "-";
		  		break;
		  	}
		  															// in this case of dealing with an operator, we set the operation string to the current
		  	case("*"):												// operator and change 'op' to being true. Op is used when we are dealing with another sum
		  	{														// as explained below
		  		op = true;
		  		operation = "*";
		  		break;
		  	}
		  	
		  	case("/"):
		  	{
		  		op = true;
		  		operation = "/";
		  		break;
		  	}
		  	
		  	case("("):																// this means there's another sum within the string
		  	{
		  		String[] copy = new String[infixLiterals.length - i - 1];			// creates a copy of the rest of the string
		  		boolean found = false;
		  		int count = 1;
		  		int other = 0;
		  		open = true;
		  		
		  		for (int k = 1; k + i < infixLiterals.length && !found; k++)		// this finds the index of the closing bracket for the opening bracket
		  		{																	// we are looking at (at index i)
		  			if (infixLiterals[i+k].equals("("))
		  			{
		  				count++;													// this if and else if statement finds the closing bracket. If we encounter
		  			}																// other opening bracket(s) for different sums, we need to make sure we don't stop
		  																			// looking for a closing bracket when it represents those inner sums
		  			else if (infixLiterals[i+k].equals(")"))						// eg in the sum 5 + (1 + (9 * 2) + 9), if we are looking at the first opening bracket
		  			{																// its closing bracket is after the second 9, not after the two. If we set found
		  				if (++other == count)										// to be true after we found the first closing brakcet we would be left with the sum
		  				{															// (1 + (9 * 2), which would be incorrect
		  					found = true;
		  				}
		  			}
		  			
		  			++gap;															// Again we are updating the gap as we will skip over the inner sum
		  		}
		  		
		  		for (int j = 0; j < copy.length; j++)
		  		{
		  			copy[j]= infixLiterals[i + j + 1];								// Copying the rest of the infixLiterals array
		  		}
		  		
		  		if (op)																// If op is true, it means that the evaluated inner sum will be evaluated
		  		{																	// as the second half of the sum. i.e 1 + (3 + 1) will become the sum
		  			y = evaluateInfixOrder(copy);									// 1 + 4
		  			second = true;
		  		}
		  		
		  		else																// If not it's the other way around. i.e. (3 + 1) + 1 will become the sum
		  		{																	// 4 + 1
		  			x = evaluateInfixOrder(copy);
		  			first = true;
		  		}
		  		
		  		break;
		  	}
		  	
		  	case(")"):																// If we come to a closing bracket we know that the inner sum is done
		  	{																		// and we can break from the for loop
		  		done = true;
		  		break;
		  	}
		  	
		  	default:																// This part of the switch statement is only reached if the current string
		  																			// is a number
		  		if (!first)															// 'first' is only true if x has been given a value. If not we will give
		  		{																	// x one
		  			x = Integer.parseInt(infixLiterals[i]);
		  			first = true;
		  		}
		  		
		  		else
		  		{
		  			y = Integer.parseInt(infixLiterals[i]);
		  			second = true;
		  		}
		  }
		  
		  if (second)																// we only do a sum operation if there is a y value
		  {
			  second = false;
			  
			  switch(operation)														// we don't immediately return 'x', as there could be more values
			  {																		// i.e. if we returned x here for the string "1 + 2 + 3", we would  
			  	case "+":															// get the result 3 not 6
			  	{
			  		x = x + y;
			  		break;
			  	}
			  
			  	case "-":
			  	{
			  		x = x - y;
			  		break;
			  	}
			  
			  	case "*":
			  	{
			  		x = x * y;
			  		break;
			  	}
			  
			  	case "/":
			  	{
			  		x = x / y;
			  		break;
			  	}
			  
			  	default:
			  	{}
			  }
		  }
		  
		  if (open)									// if we had an open bracket we skip over the contents of that bracket here
		  {
			  i += gap;
			  open = false;
		  }
		  
		  else
		  {
			  ++i;									// if not we simply look at the next string
		  }
	  }
	 
	  return x;
  }



  //~ Conversion  methods ..........................................................


  /**
   * Converts infix to postfix.
   *
   * @param infixLiterals : an array containing the string literals in infix order.
   * The method assumes that each of these literals can be one of:
   * - "+", "-", "*", or "/"
   * - or a valid string representation of an integer.
   *
   * @return the expression in postfix order.
   **/
  
  /*
   * Time complexity is Theta (N) again as we have to examine entire array. Space complexity is O(N). This is because the array, arraylist and stack needs
   * to be stored and in the absolute worst case all will be full with N number of elements. I believe this method to be most efficient as possible. The 
   * operations are popped from the stack as soon as they're added into result, meaning they're not stored in two places when they only need to be stored in 1.
   * Also the arraylist gets added to as we cycle through array, meaning it will only be as large as it needs to be. 
   * (i.e. an array that's bigger than necessary doesn't happen) 
   */
  
  public static String[] convertInfixToPostfix(String infixLiterals[])
  {
	  Stack<String> operations = new Stack<String>();
	  boolean brack = true;
	  int bCount = 0;
	  ArrayList<String> result = new ArrayList<String>();
		    	
	  for (int i = 0; i < infixLiterals.length; i++)			// cycling through the string array
	  {
		  switch(infixLiterals[i])
		  {
		  	case ("("):
		  	{
		  		bCount++;										// bCount counts how many brackets are currently open
		  		brack = true;									// brack tracks whether there is a bracket open
		  		break;
		  	}
		   		
		  	case (")"):
		  	{
		  		brack = false;
		  		bCount--;
					
		  		if (operations.size() > 0)
		  		{
		  			result.add(operations.pop());				// adding the most recently pushed operation onto the result arraylist
		  		}	
		  		break;
		  	}
		   			
		  	case ("+"):
		  	case ("-"):
		  	case ("*"):
		  	case ("/"):
		  	{
		  		operations.push(infixLiterals[i]);				// storing the operation on the operation stack
		  		break;
		  	}
		   			
		  	default:
		  	{
		  		result.add(infixLiterals[i]);					// default is only accessed by numbers. Therefore we store them directly onto result
		  	}
				
		  	if (!brack || bCount == 0)							// if a bracket was closed (ie. brack = false), we must add the operation into the result
		  	{													// it will be stored after the second variable of the sum, where it should be
		  		if (operations.size() > 0)
		  		{
		  			result.add(operations.pop());
		  		}
					
		  		if (bCount != 0)								// if the operation we added was within another set of parentheses, bCount will be greater 
		  		{												// 0. Therefore we reset brack to true, as there is currently at least one set of brackets
		  			brack = true;								// open
		  		}
		  	}
		  }
	  }
			
	  while (operations.size() > 0)								// if there are any more operations left on the operations stack we pop them off and store
	  {															// them at the end of the result
		  result.add(operations.pop());
	  }
		    	
	  String[] theResult = new String[result.size()];
		    
	  for (int i = 0; i < theResult.length; i++)
	  {
		  theResult[i] = result.get(i);
	  }
		        
	  return theResult;
  }


  /**
   * Converts postfix to infix.
   *
   * @param postfixLiterals : an array containing the string literals in postfix order.
   * The method assumes that each of these literals can be one of:
   * - "+", "-", "*", or "/"
   * - or a valid string representation of an integer.
   *
   * @return the expression in infix order.
   **/
  
  /* 
   * In the worst case we can guarantee a run-time of O(N^2). This is because there is embedded for loops, that can both run the duration of the passed array.
   * As with the infix to post-fix converter, we have a stack, arraylist and passed array. I again believe this to be the most efficient method possible for 
   * the same reasons stated above in the infix to post-fix converter description.
   */
  
  public static String[] convertPostfixToInfix(String postfixLiterals[])
  {
	  Stack<String> numbers = new Stack<String>();
	  ArrayList<String> result = new ArrayList<String>();
	  
	  for (int i = 0; i < postfixLiterals.length; i++)
	  {
		  switch (postfixLiterals[i])
		  {
		  	case ("+"):
		  	case ("-"):
		  	case ("*"):
		  	case ("/"):
		  	{
		  		try
		  		{
		  			String y = numbers.pop();				// we try popping a number off the number stack
		  			
		  			String x;
		  			
		  			try										// if there we can, we try pop another number off the number stack
		  			{
		  				x = numbers.pop();					// if again we can, it means that we have a standard sum. ie: an x and a y value and an operand
		  				result.add("(");					// we add an open bracket
		  				result.add(x);						// that x value
		  				result.add(postfixLiterals[i]);		// the operand
		  				result.add(y);						// and that y value
		  			}
		  		
		  			catch (Exception ex)					// if we don't have an x value
		  			{
		  				ArrayList <String> copy = new ArrayList<String>();
		  				copy.add("(");
		  			
		  				for (int j = 0; j < result.size(); j++)			// we make a copy of the result with an extra bracket at the start
		  				{
		  					copy.add(result.get(j));
		  				}
		  			
		  				copy.add(postfixLiterals[i]);					// then add the operand and the y value to the end
		  				copy.add(y);
		  				result = copy;
		  			}
		  		
		  			result.add(")");
		 
		  			break;
		  		}
		  		
		  		catch (Exception e)					// if there are no numbers on the stack
		  		{
		  			ArrayList<String> copy = new ArrayList<String>();
		  			copy.add("(");					// we make a copy of result with extra bracket at start
		  			
		  			for (int j = 0; j < result.size() - 1; j++)				// we then copy that result into copy
		  			{
		  				copy.add(result.get(j));
		  				
		  				if ((result.get(j).equals(")")) && result.get(j+1).equals("("))		// until we find where there is a ')' followed by a '('. This
		  				{																	// means there is an operation missing. We then add the operation
		  					copy.add(postfixLiterals[i]);									// in and copy the rest of the string
		  				}
		  			}
		  			
		  			copy.add(result.get(result.size()-1));									// add the last element of string and closing bracket
		  			copy.add(")");
		  			result = copy;
		  			break;
		  		}
		  	}
		  	
		  	default:
		  	{
		  		numbers.push(postfixLiterals[i]);											// if current string is a number, simply push it onto number stack
		  		break;
		  	}
		  }
	  
	  }
	  
	  String[] res = new String[result.size()];
	  
	  for (int j = 0; j < res.length; j++)
	  {
		  res[j] = result.get(j);
	  }
	  
	  return res;
  }

}

/*
 * 
 *  Data structures used: ArrayList and Stack
 *  
 *  Methods used:
 *  - ArrayList:
 *  	- .get(): always constant time O(1) operation.
 *  	- .add(): also runs in O(1) time, unless copying all array (O(N)) which is done a number of times in above code. 
 *  			  However as a stand alone operation, O(1).				(Source: https://www.baeldung.com/java-collections-complexity)
 *  
 *  - Stack:
 *  	- .push(): Constant time operation O(1).
 * 		- .pop(): Constant time operation as well, O(1).
 * 													(Source: https://www.geeksforgeeks.org/stack-data-structure-introduction-program/)	
 */


